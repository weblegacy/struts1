/*
 *  AcmeAction.java
 * 
 *  Copyright (C) 2002 Proact Corp.
 *  All rights reserved.
 */

package com.acme;

import jakarta.servlet.ServletException; 
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/*********************************************************************
 *
 * Description of class
 *
 * @author Nick Afshartous <nick.afshartous@proactcorp.com>
 *
 * @version $Id: AcmeAction.java,v 1.2 2003/02/20 14:17:35 afshar Exp $
 *
 *********************************************************************/

public class AcmeAction extends org.apache.struts.actions.DispatchAction {


    /*
     * Show the home page
     *
     * @param mapping The ActionMapping used to select this instance
     * @param actionForm The ActionForm bean for this request 
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     */
    public ActionForward enterName(ActionMapping mapping,
                                   ActionForm form,
                                   HttpServletRequest request,
                                   HttpServletResponse response)
        throws Exception {

        return mapping.findForward("name");

    }


    public ActionForward enterAddress(ActionMapping mapping,
                                    ActionForm form,
                                    HttpServletRequest request,
                                    HttpServletResponse response)
        throws Exception {

        return mapping.findForward("address");

    }


    public ActionForward submitAddress(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response)
        throws Exception {

        return mapping.findForward("done");

    }


    public ActionForward previous(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response)
        throws Exception {

        return mapping.findForward("previous");

    }

}